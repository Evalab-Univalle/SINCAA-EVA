require 'httpauth/constants'
require 'httpauth/exceptions'
require 'httpauth/basic'
require 'httpauth/digest'