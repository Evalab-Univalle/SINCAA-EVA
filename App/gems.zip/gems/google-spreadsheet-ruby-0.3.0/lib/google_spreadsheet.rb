# Author: Hiroshi Ichikawa <http://gimite.net/>
# The license of this source is "New BSD Licence"

require "rubygems"
require "google_drive"


GoogleSpreadsheet = GoogleDrive
