module Choice
  module Version #:nodoc:
    MAJOR  = 0
    MINOR  = 1
    TINY   = 6 
    STRING = [MAJOR, MINOR, TINY] * '.'
  end
end
