module I18n
  VERSION = "0.6.1"
end
