#ifndef EXTCONF_H
#define EXTCONF_H
#define HAVE_EXTCONF_H 1
#define USE_INTERNAL_LIBFFI 1
#endif
